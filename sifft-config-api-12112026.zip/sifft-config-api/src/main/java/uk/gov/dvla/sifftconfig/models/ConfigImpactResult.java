package uk.gov.dvla.sifftconfig.models;

import java.util.ArrayList;

public class ConfigImpactResult {

    private int writeConfigId;
    private int dependentReadConfigCount;
    private ArrayList<String> readConfigPatterns;

    public ConfigImpactResult(int writeConfigId,
                              int dependentReadConfigCount,
                              ArrayList<String> readConfigPatterns) {

        this.writeConfigId = writeConfigId;
        this.dependentReadConfigCount = dependentReadConfigCount;
        this.readConfigPatterns = readConfigPatterns;
    }

    public int getWriteConfigId() {
        return writeConfigId;
    }

    public int getDependentReadConfigCount() {
        return dependentReadConfigCount;
    }

    public ArrayList<String> getReadConfigPatterns() {
        return readConfigPatterns;
    }
}
