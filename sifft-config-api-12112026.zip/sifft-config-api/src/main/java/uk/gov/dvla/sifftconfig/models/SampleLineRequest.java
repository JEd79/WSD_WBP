package uk.gov.dvla.sifftconfig.models;

public class SampleLineRequest {

    private String sampleLine;

    public SampleLineRequest() {
    }

    public String getSampleLine() {
        return sampleLine;
    }

    public void setSampleLine(String sampleLine) {
        this.sampleLine = sampleLine;
    }
}
