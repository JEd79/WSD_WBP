package uk.gov.dvla.sifftconfig.exceptions;

public class DuplicateConfigException extends IllegalArgumentException {

    public DuplicateConfigException(String message) {
        super(message);
    }
}
