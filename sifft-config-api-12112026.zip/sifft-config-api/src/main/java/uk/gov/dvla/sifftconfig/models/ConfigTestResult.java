package uk.gov.dvla.sifftconfig.models;

public class ConfigTestResult {

    private int readConfigId;
    private int expectedFieldCount;
    private int detectedFieldCount;
    private boolean matches;

    public ConfigTestResult(int readConfigId,
                            int expectedFieldCount,
                            int detectedFieldCount,
                            boolean matches) {
        this.readConfigId = readConfigId;
        this.expectedFieldCount = expectedFieldCount;
        this.detectedFieldCount = detectedFieldCount;
        this.matches = matches;
    }

    public int getReadConfigId() {
        return readConfigId;
    }

    public int getExpectedFieldCount() {
        return expectedFieldCount;
    }

    public int getDetectedFieldCount() {
        return detectedFieldCount;
    }

    public boolean isMatches() {
        return matches;
    }
}
