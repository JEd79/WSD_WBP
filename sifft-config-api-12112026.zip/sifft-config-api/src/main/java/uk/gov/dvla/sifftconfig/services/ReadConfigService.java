
package uk.gov.dvla.sifftconfig.services;

import org.springframework.stereotype.Service;
import uk.gov.dvla.sifftconfig.models.ReadConfig;
import uk.gov.dvla.sifftconfig.models.ConfigTestResult;

import java.util.HashMap;

@Service
public class ReadConfigService {

    private HashMap<Integer, ReadConfig> readConfigs;
    private WriteConfigService writeConfigService;
    private int nextId = 1;
    private static final String DELETE_TOKEN = "sifftdelete!";

    public ReadConfigService(ConfigLoaderService loader,
                             WriteConfigService writeConfigService) {

        this.writeConfigService = writeConfigService;
        readConfigs = loader.loadReadConfigs();

        for (Integer id : readConfigs.keySet()) {
            if (id >= nextId) {
                nextId = id + 1;
            }
        }

        System.out.println("Loaded " + readConfigs.size()
                + " read configurations");
    }

    public HashMap<Integer, ReadConfig> getReadConfigs() {
        return readConfigs;
    }

    public ReadConfig getReadConfig(int id) {
        return readConfigs.get(id);
    }

    public String validateReadConfig(ReadConfig config) {

        if (config == null) {
            return "Read configuration is required";
        }

        if (config.getPattern() == null ||
                config.getPattern().isBlank()) {
            return "Filename pattern is required";
        }

        if (!",".equals(config.getDelimiter()) &&
                !"|".equals(config.getDelimiter())) {
            return "Unsupported delimiter";
        }

        if (!"auto".equals(config.getHeader()) &&
                !"true".equals(config.getHeader()) &&
                !"false".equals(config.getHeader())) {
            return "Unsupported header setting";
        }

        if (config.getColumns() == null ||
                config.getColumns().isEmpty()) {
            return "At least one column is required";
        }

        for (String column : config.getColumns()) {
            if (column == null || column.isBlank()) {
                return "Column names cannot be empty";
            }
        }

        if (writeConfigService.getWriteConfig(
                config.getWriteConfigId()) == null) {
            return "Referenced write configuration does not exist";
        }

        return null;
    }

    public boolean patternExists(String pattern) {

        for (ReadConfig config : readConfigs.values()) {
            if (config.getPattern().equalsIgnoreCase(pattern)) {
                return true;
            }
        }

        return false;
    }

    public ReadConfig addReadConfig(ReadConfig config) {

        config.setId(nextId);
        nextId++;

        readConfigs.put(config.getId(), config);

        return config;
    }


    public ConfigTestResult testReadConfig(
            ReadConfig config, String sampleLine) {

        String[] fields;

        if ("|".equals(config.getDelimiter())) {
            fields = sampleLine.split("\\|", -1);
        } else {
            fields = sampleLine.split(",", -1);
        }

        int expected = config.getColumns().size();
        int detected = fields.length;

        boolean matches = expected == detected;

        return new ConfigTestResult(
                config.getId(),
                expected,
                detected,
                matches
        );
    }


    public boolean deleteReadConfig(int id) {
        if (readConfigs.containsKey(id)) {
            readConfigs.remove(id);
            return true;
        }
        return false;
    }


    public boolean patternExistsForOtherConfig(String pattern, int id) {

        for (ReadConfig config : readConfigs.values()) {
            if (config.getId() != id &&
                    config.getPattern().equalsIgnoreCase(pattern)) {
                return true;
            }
        }
        return false;
    }


    public ReadConfig updateReadConfig(int id, ReadConfig config) {
        config.setId(id);
        readConfigs.put(id, config);
        return config;
    }



    public boolean isAccessTokenValid(String token) {
        return DELETE_TOKEN.equals(token);
    }

}
