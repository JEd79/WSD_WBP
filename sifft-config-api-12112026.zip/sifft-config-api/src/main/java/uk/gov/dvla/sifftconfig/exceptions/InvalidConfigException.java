package uk.gov.dvla.sifftconfig.exceptions;

public class InvalidConfigException extends IllegalArgumentException {

    public InvalidConfigException(String message) {
        super(message);
    }
}
