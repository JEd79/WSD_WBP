package uk.gov.dvla.sifftconfig.services;

import org.springframework.stereotype.Service;
import uk.gov.dvla.sifftconfig.models.ReadConfig;
import uk.gov.dvla.sifftconfig.models.ConfigImpactResult;

import java.util.ArrayList;

@Service
public class ConfigImpactService {

    private ReadConfigService readConfigService;

    public ConfigImpactService(ReadConfigService readConfigService) {
        this.readConfigService = readConfigService;
    }

    public ConfigImpactResult getConfigImpact(int writeConfigId) {

        ArrayList<String> patterns = new ArrayList<>();

        for (ReadConfig config :
                readConfigService.getReadConfigs().values()) {

            if (config.getWriteConfigId() == writeConfigId) {
                patterns.add(config.getPattern());
            }
        }

        int count = patterns.size();

        return new ConfigImpactResult(
                writeConfigId,
                count,
                patterns
        );
    }
}
