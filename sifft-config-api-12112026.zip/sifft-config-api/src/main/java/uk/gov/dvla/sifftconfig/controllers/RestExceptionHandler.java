package uk.gov.dvla.sifftconfig.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import uk.gov.dvla.sifftconfig.exceptions.InvalidConfigException;
import uk.gov.dvla.sifftconfig.exceptions.ConfigNotFoundException;
import uk.gov.dvla.sifftconfig.exceptions.DuplicateConfigException;

import java.util.HashMap;

@RestControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InvalidConfigException.class)
    public ResponseEntity<HashMap<String, String>> handleInvalidConfig(
            InvalidConfigException e) {

        HashMap<String, String> error = new HashMap<>();
        error.put("error", "Bad Request");
        error.put("message", e.getMessage());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(error);
    }

    @ExceptionHandler(ConfigNotFoundException.class)
    public ResponseEntity<HashMap<String, String>> handleNotFound(
            ConfigNotFoundException e) {

        HashMap<String, String> error = new HashMap<>();
        error.put("error", "Not Found");
        error.put("message", e.getMessage());

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(error);
    }

    @ExceptionHandler(DuplicateConfigException.class)
    public ResponseEntity<HashMap<String, String>> handleDuplicate(
            DuplicateConfigException e) {

        HashMap<String, String> error = new HashMap<>();
        error.put("error", "Conflict");
        error.put("message", e.getMessage());

        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(error);
    }
}
