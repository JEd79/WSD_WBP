package uk.gov.dvla.sifftconfig.exceptions;

public class ConfigNotFoundException extends IllegalArgumentException {

    public ConfigNotFoundException(String message) {
        super(message);
    }
}
