package uk.gov.dvla.sifftconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SifftConfigApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
