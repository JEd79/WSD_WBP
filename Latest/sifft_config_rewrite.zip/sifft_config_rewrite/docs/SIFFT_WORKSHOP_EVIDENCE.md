# SIFFT Workshop — Verified Evidence Notes

Source: `sifft-workshop.py` — a Databricks demo notebook shared by the SIFFT library
creators (DVLA Data Platform), demonstrating the real production system. These are facts
taken directly from that workshop, for use as **cited evidence** in the CSF2702 and CSF2753
reports. Paraphrase in the reports; do not paste large verbatim blocks.

> Reference to cite: *SIFFT Workshop — Spark Ingestion Framework For Tables*, DVLA Data
> Platform (Databricks demo notebook), 2026. Companion to the repository
> `https://github.com/dvla/sifft`.

---

## 1. The production pipeline (verified)

- Runs **in production today across Drivers, Vehicles and Lookups — 50+ file types daily**
  (stated verbatim in the workshop wrap-up).
- Deployed as a **Databricks Asset Bundle**: three scheduled tasks,
  **Pull (SFTP -> Volume) -> Ingest (Volume -> Delta) -> Cleanup (Archive + SFTP delete)**.
- Schedule: **daily at 10:30 UK** (`quartz_cron_expression: "0 30 10 * * ?"`).
- Entry point `run_ingest.py` lists files in the landing volume and calls `ingest_file()` per file.

## 2. Configuration-as-code (the as-is state the improvement targets)

The workshop shows the configuration living **in code**, consumed by the ingest job:

- `FILE_MAPPINGS` — a list of entries, each: `pattern` -> `target_table` -> `delimiter` ->
  `header` -> `columns`. The workshop states "**40+ file mappings total**".
- `get_file_mapping(filename)` matches an incoming filename to its mapping; unmatched files
  are skipped (`IngestResult.UNMATCHED`).
- `TRACKING_TABLE = "file_tracking"` is also a code constant.

This is the direct evidence that onboarding/changing a feed is a **code change** to
`FILE_MAPPINGS` plus a redeploy of the Asset Bundle — the limitation both reports' improvement
addresses by externalising this config into a managed service.

## 3. The two config concepts map exactly onto the web-service model

| SIFFT (workshop) | Web-service model (this project) |
|---|---|
| `FILE_MAPPINGS` entry: `pattern`, `delimiter`, `header`, `columns` | `ReadConfig` (pattern, delimiter, header, columns) |
| `TableWriteOptions(mode, add_source_metadata, schema_mode, ...)` | `WriteConfig` (mode, addSourceMetadata, schemaMode, format, ...) |
| CSVW constraint set (required/min/max/enum/primaryKey) | the controlled vocabulary + validation rules |

So the web service's `ReadConfig`/`WriteConfig` are faithful externalisations of real SIFFT
configuration objects, not invented abstractions.

## 4. Pluggable handlers — evidence for the Strategy pattern (CSF2702)

The workshop demonstrates custom, runtime-selected handlers:

- `register_handler(".rpt", rpt_handler, priority=10)` registers a handler for a file
  extension; `process_file` then "uses it automatically", and a higher priority "takes
  precedence over built-in handlers".
- A handler is a function conforming to a common result contract (`FileProcessingResult`).

This is real evidence that SIFFT already selects *how to read/process* by a pluggable,
interchangeable unit chosen at runtime — exactly the Strategy pattern's intent (a family of
interchangeable algorithms behind a common interface). It substantiates both the Strategy
choice and the "make behaviour pluggable/extensible" framing of the improvement.

## 5. Validation-before-load (criticality evidence, CSF2753)

- SIFFT validates against **CSVW metadata** (a W3C standard) *before* data lands:
  data types, required fields, value constraints (`minimum`/`maximum`, `enum`), and a
  `primaryKey` uniqueness rule.
- A `ValidationReport` lists violations with column, constraint type, message and row count.
- "Bad data is caught **before** it reaches the table. No silent corruption."

This supports the criticality argument: configuration correctness governs whether validation
and ingestion succeed, so managing config safely (validated, no redeploy) is operationally
significant.

## 6. Other verified production details (richness factor)

- **PD redaction**: personal-data fields are redacted with **HMAC-SHA256** using a seed held
  in **Azure Key Vault** (`dbutils.secrets.get(...)`) — supports the "secrets never in config"
  security point.
- **Source lineage**: writes add `dp_metadata_*` columns (source file, ingest time, directory)
  so "where did this data come from?" is always answerable.
- **Tracking / idempotency**: processing is tracked by **file checksum AND path**; unchanged
  files are skipped on re-run (zero rows), making the daily job safe to re-run after failure.

## 7. Scope guard (do not cross)

The workshop is **Spark/Databricks ingestion code** — a different layer from the configuration
web service built for these assignments. Use it as **evidence and context only**; do not port
any of it into the Java solution. The web service manages configuration; SIFFT performs the
ingestion. They are joined only by the shared configuration (today in code; the improvement
externalises it).
