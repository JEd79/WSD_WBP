# CSF2702 — Sections 1–4 (trimmed, cleaned, taught-level)

> Clean version for pasting into Word. Markdown code backticks are avoided (class names are in
> plain text) so nothing renders oddly. Target for the whole report is 3,000 words; the
> per-section word counts below are indicative.

---

## 1. Introduction and Description  *(~300 words)*

### 1.1 The system
SIFFT (Spark Ingestion Framework For Tables) is an in-house Python library used on the DVLA Data
Platform. It gives a consistent way to bring data files into Apache Spark: reading files of
different formats, checking data quality before it is stored, handling errors consistently, and
writing the results to Delta tables [1].

### 1.2 Use and function
A scheduled Databricks job runs SIFFT daily in three steps — Pull (collect files), Ingest (load
them into tables) and Cleanup. Two kinds of setting control each of the 50-plus daily feeds: how
a file is read (its separator, whether it has a header, its columns) and how its table is written
(the target table, format and mode).

### 1.3 Interactions with other systems
SIFFT is called by Databricks jobs, reads files delivered by SFTP into cloud storage, and writes
to Delta tables. Under the proposed improvement it would also read its settings from a separate
configuration service. The service and SIFFT do not call each other directly; they share only the
configuration the service manages and the job reads.

### 1.4 Purpose and criticality
These feeds fill tables used across DVLA for Drivers, Vehicles and Lookups data. Because the job
runs daily and checks data before loading it, the correctness of its settings is business
critical: a wrong separator or table name breaks that day's load for a whole area. Managing
settings safely, without a redeploy, is therefore important.

### 1.5 Intended end users
The direct users are the DVLA Data Platform team, who run SIFFT jobs and author feed settings.
Indirectly, everyone who uses the resulting tables depends on those settings being correct.

### 1.6 Requirements (focused scope)
SIFFT is a large library. This report focuses on the configuration and table-writing part, as
that is where the improvement and the design pattern apply. In scope: R1 represent read and write
settings as objects; R2 validate settings before accepting them; R3 hold the allowed values in
one place; R4 choose the write behaviour in a way that is easy to extend; R5 construct settings
so an invalid one cannot be created. SIFFT's file-reading internals, its validation engine and
its cloud file-management are out of scope, so the diagram stays focused.

---

## 2. Class Diagram of the System  *(insert the diagram here)*

> Insert the diagram `sifft_rewrite_uml/SYSTEM_CLASS_DIAGRAM.drawio` (exported as an image) as
> **Figure 1**, with the caption: *"Figure 1 — Detailed class diagram of the configuration
> service (8 classes)."* The descriptions in Section 3 refer to this figure.

---

## 3. Class Descriptions  *(~450 words)*

### 3.1 Classes and responsibilities
Each class is one building block with a single clear job. Together they let a user create, change,
delete and test the settings that control how files are brought into the data platform.

- **ReadConfigController** — the front door for read settings. It receives web requests, passes
  them to the service that does the work, and returns the response (including a "not found"
  message where needed). It holds no rules itself.
- **WriteConfigController** — the same front door for write settings.
- **ReadConfigService** — does the real work for read settings. It keeps the read settings and
  applies the rules (nothing required missing, a single-character separator, an allowed header
  value). It also runs the test feature: it splits a sample line using the stored separator and
  reports whether the number of fields matches.
- **WriteConfigService** — does the real work for write settings, checking the table name, the
  format and other values, and the special merge rule. It also decides whether a rejected request
  was incomplete or simply used a disallowed value, so the right message is returned.
- **BaseConfig** — a shared parent holding the one thing both settings have in common: an
  identifier. It is defined once here and never used on its own.
- **ReadConfig** — one read setting: filename pattern, separator, header choice and column names.
  It takes its identifier from BaseConfig and has simple ways to read and change each value.
- **WriteConfig** — one write setting: target table, format, mode, structure-change option, merge
  keys and a source-information flag. It also takes its identifier from BaseConfig.
- **ConfigTestResult** — a small result produced by the test feature: how many fields were found,
  how many were expected, whether they match, and the fields found.

### 3.2 Justification of each relationship
Figure 1 shows four kinds of connection; each is chosen to match a real link in the system.

| # | From | To | Multiplicity | Type | Why this type (plain terms) |
|---|---|---|---|---|---|
| 1 | ReadConfigController | ReadConfigService | — | association | The controller always relies on the service — a permanent partnership, so a solid line. |
| 2 | WriteConfigController | WriteConfigService | — | association | The same permanent partnership for write settings. |
| 3 | ReadConfigService | ReadConfig | 1 → 0..* | aggregation | The service holds a collection of read settings it groups and looks after — an open-diamond "has a", "zero or more". |
| 4 | WriteConfigService | WriteConfig | 1 → 0..* | aggregation | The same "holds a collection of" link for write settings. |
| 5 | ReadConfig | BaseConfig | — | inheritance | A read setting is a kind of configuration, sharing the identifier from the parent — hollow triangle. |
| 6 | WriteConfig | BaseConfig | — | inheritance | A write setting is also a kind of configuration. |
| 7 | ReadConfigService | ConfigTestResult | — | dependency | The service only creates a result for a moment during the test, then returns it — a one-off use, so a dashed arrow. |

The design separates **permanent links** (a controller always keeps its service) from a
**one-off use** (the service makes a result only while a test runs). Aggregation (open diamond) is
used rather than composition (filled diamond) because the settings are simple objects the service
groups together; composition is reserved for parts that cannot exist without their owner, which is
not the case here. The BaseConfig parent is genuine — both settings really share an identifier —
so the inheritance is real, not added only to use the notation.

---

## 4. Suggestion for Improvement  *(~450 words)*

### 4.1 The change
The proposed change is to take SIFFT's ingestion settings out of code and manage them through a
separate service, and to make the choice of write behaviour easy to extend. Today those settings
are written straight into the Databricks job as a hard-coded list (FILE_MAPPINGS) and write
options. Moving them out of code lets them be created, changed and removed as data, and arranging
the write step around interchangeable classes means a new table format is an added class, not an
edit to existing code.

### 4.2 The problem and its likely cause
Any settings change — a new feed, a corrected separator, a new format — currently needs a code
change and a redeploy. This is slow, needs developer access, and means a bad value is only found
when the daily job fails in production. The cause is that the settings and the behaviour choice
are both fixed into the job when it is built: the settings live as literals rather than as data
read at run time, and the write behaviour is chosen with if/else branches, so adding a format
means editing code that already works.

### 4.3 The classes responsible / requiring modification

| Concern | Class(es) | Role in the change |
|---|---|---|
| Hold the externalised read/write settings | ReadConfig, WriteConfig (and parent BaseConfig) | become data managed through the service rather than literals in code |
| Create and validate a setting | ReadConfigService, WriteConfigService | take on validating and storing settings, and (for writes) delegating the behaviour |
| Choose write behaviour by format | *(new)* FormatStrategy and its concrete strategies | replace the format if/else with interchangeable strategy classes (see Section 5) |

The classes that cause the limitation are the ones holding literals and branching on them. The
classes added or changed to fix it are the two services plus the proposed FormatStrategy classes.

### 4.4 How the change helps
- **Maintainability** — onboarding a feed becomes one API call; decommissioning becomes a delete,
  instead of editing code and redeploying.
- **Extensibility** — a new format is a new class that implements the interface; existing classes
  are untouched.
- **Testability** — smaller, separated classes can each be checked on their own.
- **Coupling and cohesion** — the change separates what to ingest (data) from how to ingest it
  (code), so each class has a single job.
- **Performance** — roughly neutral (a lookup and a call instead of inline values), negligible
  against a once-a-day batch.

### 4.5 Evidence from the existing system
SIFFT is already built to be extended: its workshop and documentation show custom handlers being
registered and chosen at run time (for example, adding a handler for a new file type so the reader
picks it up automatically) [2]. What is not externally managed today is the configuration that
drives those handlers — it still lives in code. The improvement closes that gap, and the
proof-of-concept service shows it is feasible and safe because it validates settings and rejects
bad values when they are saved.

---

### References
[1] DVLA, *Spark Ingestion Framework for Tables (SIFFT)*, GitHub, https://github.com/dvla/sifft
[2] *SIFFT Workshop*, DVLA Data Platform (Databricks demo notebook), 2026.
