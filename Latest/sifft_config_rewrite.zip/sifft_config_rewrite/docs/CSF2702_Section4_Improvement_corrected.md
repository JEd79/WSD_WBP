# CSF2702 — Section 4: Suggestion for Improvement or Extension (corrected)

> Matched to the rewritten solution and pitched to the taught level. Removed the earlier
> references to Builder and Singleton (only Strategy has been taught), the "Open-Closed
> Principle" wording (replaced with plain language), and the "36 integration tests" claim (the
> rewrite has a single context-load test). Classes named are those that actually exist in the
> rewrite.

---

## 4. Suggestion for Improvement

### 4.1 The change

The single significant change proposed is to **take SIFFT's ingestion configuration out of code
and manage it through a separate service**, and to make the choice of write behaviour easy to
extend. Today the settings that tell SIFFT how to read each file and how to write each table are
written directly into the Databricks job as a hard-coded `FILE_MAPPINGS` list and
`TableWriteOptions` values. The improvement moves those settings out of the code so they can be
created, changed and removed as data, and arranges the write step so that adding a new table
format means adding a new class rather than editing an existing block of code.

### 4.2 The existing problem and its likely cause

**Problem.** Any configuration change — onboarding a new feed, correcting a delimiter, or adding
a table format — currently needs a code change and a redeploy of the Databricks job. This is
slow, needs developer and deployment access, and means a bad value is only discovered when the
daily job runs and fails in production.

**Likely cause.** The configuration and the logic that chooses behaviour are both fixed into the
job when it is built and deployed. Two things cause this:

1. **Configuration lives in code.** The per-feed settings are literals in `FILE_MAPPINGS` and
   `TableWriteOptions`, not data the system reads at run time. There is no separation between
   *what* to ingest and *the program that* ingests it.
2. **Behaviour is chosen with branching logic.** Picking how to write a table (by `format` or
   `mode`) is done with `if`/`else` branches, so adding a new format means editing code that
   already exists and has already been tested — which is risky and easy to get wrong.

### 4.3 The classes responsible / requiring modification

Mapped onto the classes in the system (Sections 2–3):

| Concern | Class(es) | Role in the change |
|---|---|---|
| Hold the externalised read/write settings | `ReadConfig`, `WriteConfig` (and their parent `BaseConfig`) | become data managed through the service rather than literals in code |
| Create and validate a config | `ReadConfigService`, `WriteConfigService` | gain the job of validating and storing config, and (for writes) delegating the behaviour |
| Choose write behaviour by `format` | *(new)* `FormatStrategy` and its concrete strategies | replace the format `if`/`else` with interchangeable strategy classes (see Section 5) |

The classes that **cause** the limitation are the ones that today hold the literal settings and
branch on them. The classes that would be **added or changed** to remove it are the two
services (which take on validation and, for writes, delegation) plus the proposed
`FormatStrategy` classes introduced in the Design Patterns section.

### 4.4 How the change addresses the limitation — relevant factors

- **Maintainability.** Onboarding a feed changes from "edit `FILE_MAPPINGS` and redeploy" to a
  single API call, and decommissioning becomes a delete. A routine change drops from a full
  release to one request.
- **Extensibility.** With the write behaviour chosen through a `FormatStrategy`, adding a new
  format is just a new class that implements the interface — the existing strategy classes and
  the service that uses them do not have to change.
- **Testability.** Smaller, separated classes are easier to test on their own: each strategy can
  be checked by itself, and the services can be checked without the whole job running.
- **Coupling and cohesion.** The change separates *what* to ingest (data) from *how* to ingest
  it (code), and gives each strategy a single job. This lowers coupling and raises cohesion
  compared with a job that mixes the settings and the branching logic together.
- **Performance (honest note).** The change is roughly neutral for performance — a config lookup
  and a strategy call instead of inline literals — and any small cost is negligible against a
  once-a-day batch, and is outweighed by the maintainability and safety gains.

### 4.5 Evidence from the existing system

The change suits the system because SIFFT is already built to be extended. Its own workshop and
documentation show **custom, pluggable handlers** being registered and chosen at run time (for
example, registering a handler for a new file type so that the reader picks it up
automatically), and it describes support for custom format handlers, write modes and validators.
What is *not* externally managed today is the **configuration** that drives those handlers —
that still lives in code. The improvement closes exactly that gap. The proof-of-concept web
service demonstrates the idea is feasible and safe: it validates configuration against SIFFT's
rules and rejects bad values when they are saved, rather than letting them reach the daily job.

---

### References
[1] DVLA, *Spark Ingestion Framework for Tables (SIFFT)*, GitHub, `https://github.com/dvla/sifft`.
[2] *SIFFT Workshop*, DVLA Data Platform (Databricks demo notebook), 2026.
