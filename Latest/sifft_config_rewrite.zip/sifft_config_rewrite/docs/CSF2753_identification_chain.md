# CSF2753 — How the configuration was identified as "what needs to change"

> A defensible passage for the "Design and Justification" (or "Introduction") section. It states
> honestly how the configuration was identified as the part to externalise, and maps the as-is
> SIFFT settings to the to-be Java model. The source locations below were verified by reading the
> cloned SIFFT library (C:\sifft-main) and the workshop notebook. Cite the SIFFT sources
> consistently with the rest of the report.

---

## Identifying the part of SIFFT to change

SIFFT is a mature Python library, so the aim was not to rebuild it but to identify a single,
well-bounded limitation that a web service could address. That limitation is **how SIFFT's
per-feed configuration is held and deployed**.

Two things are true of the current (as-is) system, confirmed from SIFFT's own code and
demonstration materials:

- The **allowed values** and the **write-options object** are part of the library. The constants
  `FORMATS`, `MODES` and `SCHEMA_MODES` are defined in `table_writing/config.py`, and the
  write-options object `TableWriteOptions` (a dataclass with `format`, `mode`, `partition_by`,
  `schema_mode`, `merge_keys`, `create_if_not_exists`, `add_source_metadata`,
  `source_metadata_columns`, `extra_metadata`) is defined in `table_writing/models.py` [2]. The
  read-side defaults (per-extension delimiters, `header = "auto"`, `MAX_CORRUPT_RECORDS_PERCENT`)
  are in `file_processing/config.py` [2].
- The **per-feed configuration that ties a specific file to a table is not in the library at all**
  — it lives in the *consuming job*. The workshop shows this as a `FILE_MAPPINGS` list ("40+ file
  mappings total"), where each entry pairs a filename pattern with a target table, delimiter,
  header and column names, read by `get_file_mapping(filename)` and deployed with the job as a
  Databricks Asset Bundle [1].

Because that per-feed configuration is compiled and deployed with the job, any change —
onboarding a new feed, correcting a delimiter, or adding a table format — requires a code edit
and a redeploy, and a bad value is only discovered when the daily job fails. **This coupling of
configuration to code is the limitation the web service targets.**

## How the as-is maps to the to-be (Java service)

The change is to move *where the configuration lives and how it is managed*, not to reimplement
SIFFT. The mapping, stated precisely:

| As-is (SIFFT / job) | Source location | To-be (Java service) |
|---|---|---|
| `TableWriteOptions` (write-options object) | `table_writing/models.py` [2] | `WriteConfig` — a **simplified subset** (keeps `targetTable`, `format`, `mode`, `schemaMode`, `mergeKeys`, `addSourceMetadata`; omits `partition_by`, `create_if_not_exists`, `source_metadata_columns`, `extra_metadata`) |
| `FORMATS` / `MODES` / `SCHEMA_MODES` constants | `table_writing/config.py` [2] | the allowed-value lists held in `WriteConfigService` (same values) |
| Per-feed read settings, currently split between the job's `FILE_MAPPINGS` entry and the library defaults | `FILE_MAPPINGS` in the job [1]; defaults in `file_processing/config.py` [2] | `ReadConfig` — a **new consolidation** of those scattered settings into one object (pattern, delimiter, header, columns) |

Two points to be precise about, so the mapping is not overstated:

1. **`WriteConfig` is a simplified subset of `TableWriteOptions`, not a one-to-one copy.** The
   prototype keeps the fields relevant to the proof of concept and omits the rest; this is a
   deliberate scoping choice, not an attempt to reproduce the whole object.
2. **`ReadConfig` does not correspond to a single existing SIFFT class.** SIFFT has no unified
   "read config" type; the read settings are spread across the job's `FILE_MAPPINGS` entry and
   the `file_processing` defaults. `ReadConfig` is therefore a new object the design introduces to
   bring those settings together as one managed resource — which is itself part of the
   improvement.

The web service externalises these settings as managed REST resources that can be created,
changed and removed as data, while SIFFT itself continues to perform the ingestion. The two never
call each other directly; they share only the configuration — held in code today, managed by the
service under the proposed design.

> **Honesty note (for the writer — remove before submission):** the source locations above were
> verified by reading the cloned SIFFT library. State the mapping as it is: the write-options
> object and vocabulary are real library types (`table_writing/models.py`, `config.py`);
> `FILE_MAPPINGS` is in the consuming job shown in the workshop, not in the library; and
> `ReadConfig` is a new consolidation, not an existing SIFFT class. Do not claim `WriteConfig`
> copies `TableWriteOptions` exactly — it is a subset.

---

### References
[1] DVLA Data Platform (2026) *SIFFT Workshop* [Databricks demonstration notebook]. Internal
material.
[2] DVLA (2026) *Spark Ingestion Framework for Tables (SIFFT)*. Available at:
https://github.com/dvla/sifft (Accessed: 25 October 2026). Specific files: `table_writing/config.py`,
`table_writing/models.py`, `file_processing/config.py`.
