# CSF2753 — Workshop-Sourced Evidence Supplement

Additions to strengthen the CSF2753 report with first-hand evidence from the SIFFT workshop
(`sifft-workshop.py`, DVLA Data Platform demo). Slot into the existing sections; all points
paraphrased with a citation.

> Cite as: *SIFFT Workshop*, DVLA Data Platform (Databricks demo notebook), 2026.

---

## For Introduction & Description

**Use/function and production reality (verified).** The SIFFT workshop confirms the library
runs in production across Drivers, Vehicles and Lookups, handling 50+ file types daily. It is
deployed as a Databricks Asset Bundle with three scheduled tasks — Pull (SFTP to Volume),
Ingest (Volume to Delta), Cleanup (Archive + SFTP delete) — running daily at 10:30 UK. The
ingest task lists files in the landing volume and processes each against its configuration.

**The business problem (verified as-is state).** Configuration lives in code: a `FILE_MAPPINGS`
list ("40+ file mappings total") pairing each filename pattern with a target table, delimiter,
header and column names, consumed by the ingest job. Changing or onboarding a feed therefore
means a code change and an Asset Bundle redeploy — the limitation the web service removes by
externalising this configuration as managed REST resources.

## For Criticality

The workshop shows SIFFT validates data against CSVW metadata *before* it lands — data types,
required fields, value constraints (minimum/maximum, enum) and primary-key uniqueness — and
states that "bad data is caught before it reaches the table. No silent corruption." Because the
daily pipeline feeds curated Delta tables used across the business, and because validation and
ingestion are driven by the configuration, configuration correctness is business-critical.
Rejecting invalid configuration at write time (the web service's role) moves failure left, out
of the production batch.

## For Security, Maintainability and Versioning

**Security — secrets stay out of configuration (verified).** The production job retrieves an
HMAC seed from Azure Key Vault (`dbutils.secrets.get(...)`) and redacts personal-data fields
with HMAC-SHA256. This confirms that credentials and sensitive seeds live in a secrets manager,
never in a read/write-config body — the exact separation the web service preserves (the config
models *what* to ingest and *how*, never secrets).

**Maintainability — the redeploy problem is real.** Evidence from the workshop (config in
`FILE_MAPPINGS`, deployed via Asset Bundle) substantiates the maintainability argument:
externalising config converts a code-change-plus-redeploy into a single API call, and
decommissioning into a delete.

## For Inputs/Outputs (supporting realism)

The workshop's own demo data matches the web service's expectations and can be reused as
realistic demonstration data: `Customers.csv` with columns `customer_id, name, age, status`
and rows such as `1,Alice,34,active`. Using this data keeps the PoC screenshots consistent
with the real system.

---

### Reference
[SIFFT-WS] *SIFFT Workshop — Spark Ingestion Framework For Tables*, DVLA Data Platform
(Databricks demo notebook), 2026. Companion to `https://github.com/dvla/sifft`.
