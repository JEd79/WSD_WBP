# CSF2702 — Section 3: Class Descriptions (corrected to match the rewrite)

> Matches the rewritten solution in `C:\WSD_WBP\sifft_config_rewrite` and the regenerated
> class diagram (`sifft_rewrite_uml\SYSTEM_CLASS_DIAGRAM.drawio`): **8 classes, 7
> relationships**. No JPA, repositories, DTOs or typed exceptions — those were removed when the
> solution was simplified to the level taught in the module. Getters, setters and constructors
> are shown on the model classes, as the brief requires.

---

## 3. Class Descriptions

### 3.1 Classes and responsibilities

**`ReadConfigController` «RestController»** — the HTTP entry point for read-configuration
requests. It is deliberately *thin*: it maps the HTTP verbs (GET, POST, PUT, DELETE) to calls
on `ReadConfigService` and turns the result into the right response (201 on create, 204 on
delete, 404 when a config is not found, 200 otherwise). It holds a reference to the service and
no business logic of its own.

**`WriteConfigController` «RestController»** — the same role for write configurations. It maps
the HTTP verbs to `WriteConfigService` and returns the correct status code (including 422 when a
value is not in the allowed vocabulary). It also holds no business logic.

**`ReadConfigService` «Service»** — the class that actually does the work for read configs. It
holds the read configs in an in-memory list with an id counter, and contains the business rules:
checking required fields, that the delimiter is a single character, and that the header is one of
the allowed values; checking a pattern is not already used; and the `test` operation, which
performs the server-side processing (it splits a sample line using the stored delimiter and
reports whether the field count matches the configured columns).

**`WriteConfigService` «Service»** — the equivalent for write configs. It holds the write configs
in memory and contains the write rules: required fields, the target-table name check, that
`format`, `mode` and `schemaMode` are in the allowed lists, and the conditional merge rule
(`merge` needs merge keys and only works with `delta`). A small helper reports whether a failure
is a vocabulary problem, so the controller can return 422 rather than 400.

**`BaseConfig` «abstract»** — a shared parent class holding the one attribute both config types
have: the server-assigned `id`, with its getter and setter. It is abstract because a plain
"config" is never created on its own. `ReadConfig` and `WriteConfig` inherit from it.

**`ReadConfig`** — a plain model object describing how an inbound file is read: `pattern`,
`delimiter`, `header` and `columns`. It inherits `id` from `BaseConfig`, has a no-argument
constructor, and a full set of getters and setters.

**`WriteConfig`** — a plain model object describing how a table is written: `targetTable`,
`format`, `mode`, `schemaMode`, `mergeKeys` and `addSourceMetadata`. It also inherits `id` from
`BaseConfig`, has a no-argument constructor, and full getters and setters (including
`isAddSourceMetadata()` for the boolean).

**`ConfigTestResult`** — a small model object holding the result of a read-config test:
`detectedFieldCount`, `expectedFieldCount`, `matches` and `detectedFields`. It is created by
`ReadConfigService` during the test operation and returned to the client. It has a constructor
that sets all four fields and getters to read them.

### 3.2 Justification of each relationship

The diagram uses four relationship types; each is chosen to reflect a real link in the code.

| # | Relationship | UML type | Why this type |
|---|---|---|---|
| 1 | `ReadConfigController -> ReadConfigService` | association | the controller holds the service as a field (set through its constructor) and calls it on every request — a permanent link, so a solid association with a navigable arrow to the service. |
| 2 | `WriteConfigController -> WriteConfigService` | association | the same held-reference link for write configs. |
| 3 | `ReadConfigService <>-- ReadConfig` (1 -> 0..*) | aggregation | the service keeps a list of read configs. The configs are the "parts" the service groups together, so an unfilled diamond at the service end, with `0..*` showing it can hold any number. |
| 4 | `WriteConfigService <>-- WriteConfig` (1 -> 0..*) | aggregation | the same "has a list of" link for write configs. |
| 5 | `ReadConfig --|> BaseConfig` | inheritance (generalisation) | `ReadConfig` *is a type of* `BaseConfig`, inheriting its `id` attribute and accessors — shown with a hollow triangle pointing to the parent. |
| 6 | `WriteConfig --|> BaseConfig` | inheritance (generalisation) | `WriteConfig` is also a type of `BaseConfig`, inheriting `id`. |
| 7 | `ReadConfigService ..> ConfigTestResult` | dependency | the service *creates and returns* a `ConfigTestResult` inside its `test` method but does not keep one as a field — a transient "uses" link, so a dashed arrow (dependency). |

Two design points worth noting. First, the split between **solid associations** (the controller
permanently holds its service) and the **dashed dependency** (the service only momentarily
creates a `ConfigTestResult`) shows the difference between a collaborator an object *keeps* and
one it merely *uses*. Second, the **aggregation** (unfilled diamond) is used rather than
composition because, in this in-memory design, the configs are simple objects the service groups
together; the lecture's filled-diamond composition is reserved for parts that cannot exist apart
from their whole, which does not apply here.

> **Note on inheritance:** the `BaseConfig` superclass is a genuine part of the design — both
> config types share the `id` attribute — so the inheritance relationship is real, not added only
> to use the notation.
