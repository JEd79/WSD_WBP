# CSF2702 — Workshop-Sourced Evidence Supplement

Additions to strengthen the CSF2702 report with first-hand evidence from the SIFFT workshop
(`sifft-workshop.py`, DVLA Data Platform demo). Slot these into the existing sections. All
points are paraphrased, with a citation to the workshop.

> Cite as: *SIFFT Workshop*, DVLA Data Platform (Databricks demo notebook), 2026.

---

## For the Improvement / Extension section

**Evidence that the limitation is real (configuration-as-code).**
The SIFFT workshop shows the ingestion configuration held in code as a `FILE_MAPPINGS` list
("40+ file mappings total"), each entry pairing a filename `pattern` with a `target_table`,
`delimiter`, `header` and `columns`. The ingest task calls `get_file_mapping(filename)` to
match a file to its config; files with no mapping are skipped as "unmatched". Because this
list is a code constant deployed in a Databricks Asset Bundle, onboarding or changing a feed
requires editing source and redeploying the bundle. This is direct evidence for the problem
the improvement addresses: externalising the configuration so a feed change becomes a managed
API call rather than a code change and release.

**The classes responsible map onto real SIFFT objects.** The workshop's `FILE_MAPPINGS` entry
(pattern/delimiter/header/columns) corresponds to the `ReadConfig` class, and its
`TableWriteOptions(mode, add_source_metadata, schema_mode, ...)` corresponds to `WriteConfig`.
The improvement therefore modifies/externalises objects that genuinely exist in the system,
not invented ones.

## For Design Pattern 1 — Strategy (adds concrete evidence)

**SIFFT already uses a Strategy-style mechanism.** The workshop demonstrates
`register_handler(".rpt", rpt_handler, priority=10)`: a custom file-processing handler is
registered for an extension, and `process_file` then selects and uses it automatically, with
priority deciding precedence over built-in handlers. Each handler is a function conforming to
a common result contract (`FileProcessingResult`).

This is authentic evidence that the system selects *how a file is processed* by an
interchangeable, runtime-chosen unit behind a common interface — precisely the Strategy
pattern's intent (encapsulate a family of algorithms; make them interchangeable). It
strengthens the justification that applying Strategy to the externalised configuration
(selecting a write/format behaviour from the stored `format`) is a faithful extension of how
SIFFT is already built, not a contrived fit. It also reinforces the lecture's principles of
*programming to an interface* and *composition/delegation* over conditional branching.

## For the Introduction / richness

The workshop evidences a genuinely complex production system: a daily (10:30 UK) three-task
Databricks job (Pull -> Ingest -> Cleanup) over 50+ feeds, with CSVW validation before load,
HMAC-SHA256 personal-data redaction keyed from Azure Key Vault, source-lineage columns, and
checksum+path tracking for idempotent re-runs. Citing these supports a high richness factor.

---

### Reference
[SIFFT-WS] *SIFFT Workshop — Spark Ingestion Framework For Tables*, DVLA Data Platform
(Databricks demo notebook), 2026. Companion to `https://github.com/dvla/sifft`.
