# CSF2702 — Section 3: Class Descriptions (plain-English version)

> Describes the eight classes in the class diagram and justifies each type of relationship,
> written to be readable by a non-technical reader. Matches the rewritten solution
> (`C:\WSD_WBP\sifft_config_rewrite`) and the diagram
> (`sifft_rewrite_uml\SYSTEM_CLASS_DIAGRAM.drawio`): 8 classes, 7 relationships.

---

## 3. Class Descriptions

### 3.1 What each class does

Each class is one "building block" of the system, with a single clear job. Together they let a
user create, change, delete and test the settings that control how files are brought into the
data platform.

**ReadConfigController** — the front door for anything to do with *read* settings (how an
incoming file should be read). When a request arrives over the web, this class receives it,
passes it on to the part of the system that does the real work, and sends back the answer —
including a success or "not found" message. It does not contain any of the rules itself; it just
takes requests in and hands responses back.

**WriteConfigController** — the same kind of front door, but for *write* settings (how a table
should be written). It receives web requests about write settings, passes them on, and returns
the result.

**ReadConfigService** — the part that actually does the work for read settings. It keeps the
list of read settings the system is holding and applies all the rules: checking nothing required
has been left out, that the separator between fields is a single character, and that the "has a
header row" option is one of the allowed answers. It also runs the **test** feature, which takes
a sample line of data, splits it up using the stored separator, and reports whether it produced
the expected number of fields.

**WriteConfigService** — the part that does the work for write settings. It keeps the list of
write settings and checks them against the rules: that the table name is sensible, that the file
format and the other options are ones the system allows, and that the special "merge" option is
only used when it is valid. It decides whether a rejected request was simply incomplete or used a
value the system does not allow, so the right message can be returned.

**BaseConfig** — a shared "parent" that holds the one thing both kinds of setting have in common:
an identifier (a unique reference number). Rather than repeat this in two places, it is defined
once here. It is never used on its own — it only exists to be shared.

**ReadConfig** — represents one read setting: the pattern that matches a filename, the character
that separates the fields, whether the file has a header row, and the list of column names. It
carries its own reference number (shared from BaseConfig) and simple ways to read and change each
of its values.

**WriteConfig** — represents one write setting: the target table name, the file format, the write
mode, how the table's structure may change, any merge keys, and whether to add source
information. Like ReadConfig, it has its own reference number and simple ways to read and change
each value.

**ConfigTestResult** — a small result slip produced when the test feature runs. It records how
many fields were found, how many were expected, whether those two match, and the actual fields
that were found, so the answer can be handed back to the user.

### 3.2 Why each relationship is the type it is

The diagram shows four kinds of connection between the classes. Each kind is chosen to describe,
in UML, a real relationship in the system.

| # | Connection | Type of relationship | Why this is the right type (in plain terms) |
|---|---|---|---|
| 1 | ReadConfigController to ReadConfigService | **association** (a lasting link) | The controller always has, and relies on, the service to do the real work — a permanent working partnership, so a plain solid line pointing to the service. |
| 2 | WriteConfigController to WriteConfigService | **association** (a lasting link) | The same permanent partnership for write settings. |
| 3 | ReadConfigService to ReadConfig | **aggregation** ("has a collection of") | The service holds a collection of read settings. They are things it groups together and looks after, so an open-diamond "has a" link, marked "zero or more" because it may hold any number. |
| 4 | WriteConfigService to WriteConfig | **aggregation** ("has a collection of") | The same "holds a collection of" link for write settings. |
| 5 | ReadConfig to BaseConfig | **inheritance** ("is a kind of") | A read setting *is a kind of* configuration, so it takes the shared identifier from the parent rather than defining its own. Shown with a hollow triangle pointing to the parent. |
| 6 | WriteConfig to BaseConfig | **inheritance** ("is a kind of") | A write setting is also a kind of configuration, sharing the same identifier from the parent. |
| 7 | ReadConfigService to ConfigTestResult | **dependency** ("briefly uses") | The service only creates a result slip for a moment while running the test, then hands it back; it does not keep one. A passing, one-off use like this is shown as a dashed "depends on" arrow rather than a permanent link. |

Two points explain the choices. First, there is a deliberate difference between the **permanent
links** (a controller always keeps its service) and the **one-off use** (the service makes a
result slip only while a test runs). Showing these differently makes clear which partnerships
last and which are momentary. Second, the "has a collection of" links are shown as **aggregation**
(an open diamond) rather than the stronger **composition** (a filled diamond): composition is
reserved for parts that could not exist at all without their owner, which is not the case here,
so the lighter "has a" relationship is the honest choice.

> **Note on inheritance:** the shared BaseConfig parent is genuine — both kinds of setting really
> do share an identifier — so the "is a kind of" relationship reflects the real design, not a
> connection added only to use the notation.
