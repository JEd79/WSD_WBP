# CSF2702 — Sections 5–6 (clean, taught-level)

> Clean version for pasting into Word. Headings are plain text (no markdown # markers to carry
> across). Class names in plain text (no backticks). Fixes the duplicate "5.1" numbering and
> adds a clarifier that the patterns are *proposed* designs, not in the prototype code.

---

## 5. Design Patterns

> **Important:** the patterns below are **proposed** designs that show how the system *could* be
> extended. They are not part of the current prototype code; the prototype has the eight classes
> in Section 3. This matches the brief, which asks how a pattern could be applied.

### 5.1 What a design pattern is
A design pattern is a common, reusable solution to a problem that keeps coming up in software
design — a "problem and solution in context" rather than finished code [1]. The idea was
popularised by the Gang of Four (Gamma, Helm, Johnson and Vlissides) in *Design Patterns:
Elements of Reusable Object-Oriented Software* [1]. The three principles from the module that
motivate the pattern used here are: program to an interface, not an implementation; favour
composition over inheritance; and use delegation.

### 5.2 Pattern 1 — Strategy

**Purpose.** Strategy defines a family of related algorithms, places each in its own class behind
a common interface, and makes them interchangeable so the one to use can be chosen at run time
[1]. The object that needs the algorithm (the context) delegates to the chosen class rather than
containing the algorithm itself.

**The type of problem it addresses.** Strategy addresses the situation where one behaviour varies
among several alternatives and the set of alternatives is expected to grow. Handling that with
branching logic (if format == "delta" ... else if ...) means the part that varies is tangled with
the part that does not, and every new alternative requires editing code that already works.
Replacing such conditional statements with interchangeable classes is a recognised refactoring
towards the Strategy pattern [2].

**Main structure.** The pattern has three roles: a *strategy interface* declaring the varying
operation; several *concrete strategies* that each implement it differently; and a *context* that
holds a reference to a strategy and delegates the work to it. The context depends only on the
interface, so concrete strategies can be swapped without changing it.

**How it could be applied to the improvement.** In the improved system, how a table is written
varies by its format (delta, parquet, orc). A FormatStrategy interface would declare one
operation, write(...). Each format would be its own concrete class — DeltaStrategy,
ParquetStrategy, OrcStrategy — implementing that operation in its own way. The context,
WriteConfigService, would hold a FormatStrategy and delegate the write to it. Because the
externalised configuration stores the format as a value, that stored value selects which strategy
the context uses, and adding a new format means adding a new class rather than editing the
existing ones. The low-level class diagram for this is shown in Figure 2.

*Figure 2 — Strategy pattern applied to the write-format behaviour (proposed design).*

**Interface, not inheritance.** FormatStrategy is deliberately an interface rather than a shared
parent class. The module's guidance is to program to an interface and to favour composition over
inheritance: here the formats share a *capability* (how to write), not state, so an interface the
context composes is the right tool. Inheritance is used elsewhere, for shared *state* — BaseConfig
in Section 3 — which shows each mechanism applied to the job it suits.

**Advantages.** Each write behaviour is encapsulated and can be reused on its own; the behaviour
can be changed at run time by swapping the strategy; the context depends on an interface, not on
concrete formats, which lowers coupling; and a new format is a new class that leaves existing
classes untouched.

**Disadvantages.** It introduces more classes than a single block of branching (one per
behaviour), which is the recognised cost of the pattern [1]; the context, or the code around it,
still has to select the correct strategy; and there is a small run-time cost in delegating to
another object rather than running inline code.

**Why it is appropriate.** The improvement is fundamentally about choosing write behaviour from
stored configuration, which is exactly the problem Strategy solves. It also fits how the existing
system is already built: SIFFT models its write formats as a set of interchangeable handler
classes behind a common type, selected at run time (Section 4.5) [3]. Applying Strategy in the
configuration service is therefore a faithful restatement of a design the system already relies
on, not a contrived fit.

### 5.3 Other candidate patterns (provisional — not yet taught)
These are not final choices. Based on earlier, informal exposure they look like good comparisons
for Strategy; each will be developed once it is taught (Decorator next week, Observer later).

- **Decorator** — could wrap optional add-ons (such as adding source information, or tracking)
  around a core write, instead of hard-coding them. Benefit: add responsibilities without many
  subclasses. Cost: many small wrapper classes and order can matter.
- **Observer** — could let several things react when an ingestion run finishes (recording
  tracking, metrics, notifications) without the core process depending on each. Benefit: decoupled
  reactions. Cost: the flow of control is harder to follow.

---

## 6. Evaluation

The brief asks which of the three patterns would be most effective for the improvement. On
current understanding — having been taught Strategy, with Decorator and Observer still to come —
Strategy is the most effective, and the reasons can be judged against the factors the module
stresses: flexibility to change, reuse and simplicity.

### 6.1 Strategy — the most effective
Strategy targets the heart of the improvement: letting the write behaviour change without editing
existing code.
- **Flexibility to change.** A new format is a new class that implements the interface; the
  existing strategies and the service that uses them do not change. This is the single biggest
  gain over today's approach, where a new format means editing code that already works.
- **Reuse.** Because each write behaviour is its own class, it can be reused wherever that format
  is needed, rather than being locked inside one large method.
- **Simplicity and cost.** Strategy adds classes (one per format) and the context must still
  choose which to use. For a small, growing set of formats this cost is modest and worthwhile.
- **Fit with the system.** SIFFT already uses pluggable handlers chosen at run time (Section 4.5),
  so Strategy matches how the system is really built — it is evidenced, not forced.

### 6.2 The other two candidates (provisional)
- **Decorator** would address a different need — adding optional extras *around* a write rather
  than choosing *which* write runs. It looks like a complement to Strategy, not a competitor:
  Strategy chooses the algorithm, Decorator layers extras on top. Its likely cost is many small
  wrapper classes.
- **Observer** would address reacting to an event (a run finishing) rather than choosing
  behaviour. That is useful but further from the core improvement, so on current understanding it
  is the weakest fit of the three for this particular change.

### 6.3 Conclusion
Strategy is the most effective pattern for this improvement because the improvement is fundamentally
about choosing write behaviour from stored configuration — exactly the problem Strategy solves. It
gives the best flexibility and reuse at an acceptable cost, and it reflects how SIFFT already
works. Decorator looks like a useful complement and Observer the least central; both will be
confirmed once taught, so that the final comparison rests on properly learned material rather than
assumption.

---

### References

> Note: the two SIFFT sources are numbered [3] and [4] here so they continue the report's single
> reference list (assuming Sections 1–4 used [1] and [2] for SIFFT). If your report numbers
> references per their first appearance across the whole document, renumber consistently and use
> one citation style throughout, as the brief requires. Entries are in a Harvard-style format;
> verify details against each source before submitting.

[1] Gamma, E., Helm, R., Johnson, R. and Vlissides, J. (1994) *Design Patterns: Elements of
Reusable Object-Oriented Software*. Reading, MA: Addison-Wesley.

[2] Christopoulou, A., Giakoumakis, E.A., Zafeiris, V.E. and Soukara, V. (2012) 'Automated
refactoring to the Strategy design pattern', *Information and Software Technology*, 54(9),
pp. 1202–1214. Available at: https://doi.org/10.1016/j.infsof.2012.04.001 (verify page range
and DOI before use).

[3] Gamma, E., Helm, R., Johnson, R. and Vlissides, J. (1993) 'Design Patterns: Abstraction and
Reuse of Object-Oriented Design', in *ECOOP '93 — Object-Oriented Programming*. Berlin:
Springer (Lecture Notes in Computer Science, vol. 707), pp. 406–431.

[4] DVLA (2026) *Spark Ingestion Framework for Tables (SIFFT)* [source code]. Available at:
https://github.com/dvla/sifft (Accessed: 24 October 2026).

[5] DVLA Data Platform (2026) *SIFFT Workshop* [Databricks demonstration notebook]. Internal
material.

**Module material:** Gaya, R. (2026) *Introduction to Design Patterns and the Strategy Pattern*
(CSF2702, Week 5), including the SimUDuck / FlyBehaviour worked example. Swansea University.