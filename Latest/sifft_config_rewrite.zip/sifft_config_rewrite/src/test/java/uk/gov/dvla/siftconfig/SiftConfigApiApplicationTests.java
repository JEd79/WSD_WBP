package uk.gov.dvla.siftconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiftConfigApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
