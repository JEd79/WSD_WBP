package uk.gov.dvla.siftconfig;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiftConfigApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SiftConfigApiApplication.class, args);
    }

}
