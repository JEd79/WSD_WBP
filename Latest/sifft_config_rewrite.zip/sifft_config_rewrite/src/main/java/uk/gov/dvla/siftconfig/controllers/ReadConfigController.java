package uk.gov.dvla.siftconfig.controllers;

import uk.gov.dvla.siftconfig.models.ConfigTestResult;
import uk.gov.dvla.siftconfig.models.ReadConfig;
import uk.gov.dvla.siftconfig.services.ReadConfigService;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for read configs. Thin: it maps HTTP requests to the service
 * and turns the result into the right ResponseEntity. The /test endpoint asks
 * the service to do the server-side processing.
 */
@RestController
@RequestMapping("/api/v1/read-configs")
public class ReadConfigController {

    private final ReadConfigService service;

    public ReadConfigController(ReadConfigService service) {
        this.service = service;
    }

    @GetMapping
    public List<ReadConfig> getAllReadConfigs() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReadConfig> getReadConfig(@PathVariable int id) {
        ReadConfig found = service.findById(id);
        if (found == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(found);
    }

    @PostMapping
    public ResponseEntity<?> createReadConfig(@RequestBody ReadConfig readConfig) {
        String error = service.validate(readConfig);
        if (error != null) {
            return ResponseEntity.badRequest().body(error);
        }
        // 409 if the pattern is already used
        if (service.findByPattern(readConfig.getPattern()) != null) {
            return ResponseEntity.status(409).body("A read config with this pattern already exists");
        }
        ReadConfig saved = service.save(readConfig);
        return ResponseEntity.status(201).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateReadConfig(@PathVariable int id, @RequestBody ReadConfig updated) {
        ReadConfig existing = service.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        String error = service.validate(updated);
        if (error != null) {
            return ResponseEntity.badRequest().body(error);
        }
        return ResponseEntity.ok(service.replace(existing, updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteReadConfig(@PathVariable int id) {
        ReadConfig existing = service.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        service.delete(existing);
        return ResponseEntity.noContent().build();
    }

    // R6 - test a config against a sample line (server-side processing)
    @PostMapping("/{id}/test")
    public ResponseEntity<?> testReadConfig(@PathVariable int id, @RequestBody ReadConfig sample) {
        ReadConfig existing = service.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        // the sample line is sent in the "pattern" field of the body for simplicity
        String sampleLine = sample.getPattern();
        if (sampleLine == null) {
            return ResponseEntity.badRequest().body("sampleLine is required");
        }
        ConfigTestResult result = service.test(existing, sampleLine);
        return ResponseEntity.ok(result);
    }
}
