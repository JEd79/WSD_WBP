package uk.gov.dvla.siftconfig.models;

import java.util.List;

/**
 * The result of testing a read config against a sample line.
 * Holds what the server worked out when it split the line.
 */
public class ConfigTestResult {

    private int detectedFieldCount;
    private int expectedFieldCount;
    private boolean matches;
    private List<String> detectedFields;

    public ConfigTestResult(int detectedFieldCount, int expectedFieldCount,
                            boolean matches, List<String> detectedFields) {
        this.detectedFieldCount = detectedFieldCount;
        this.expectedFieldCount = expectedFieldCount;
        this.matches = matches;
        this.detectedFields = detectedFields;
    }

    public int getDetectedFieldCount() {
        return detectedFieldCount;
    }

    public int getExpectedFieldCount() {
        return expectedFieldCount;
    }

    public boolean isMatches() {
        return matches;
    }

    public List<String> getDetectedFields() {
        return detectedFields;
    }
}
