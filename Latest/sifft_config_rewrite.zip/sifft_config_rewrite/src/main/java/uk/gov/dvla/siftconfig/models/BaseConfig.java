package uk.gov.dvla.siftconfig.models;

/**
 * Shared base class for the two kinds of configuration.
 * Both ReadConfig and WriteConfig have a server-assigned id, so that common
 * attribute and its getter/setter live here and are inherited.
 * Abstract because a plain "config" is never created on its own.
 */
public abstract class BaseConfig {

    private Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
