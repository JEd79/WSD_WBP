package uk.gov.dvla.siftconfig.services;

import uk.gov.dvla.siftconfig.models.WriteConfig;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

/**
 * Holds the write configs in memory and contains the business rules.
 * A Spring service, following the course's "service" package example.
 * The controller stays thin and asks this class to do the work.
 */
@Service
public class WriteConfigService {

    // The allowed values SIFFT accepts (the "vocabulary").
    private static final List<String> FORMATS = Arrays.asList("delta", "parquet", "orc");
    private static final List<String> MODES = Arrays.asList("append", "overwrite", "merge", "errorIfExists");
    private static final List<String> SCHEMA_MODES = Arrays.asList("strict", "merge", "overwrite");

    private List<WriteConfig> writeConfigs = new ArrayList<>();
    private int idCounter = 1;

    public List<WriteConfig> findAll() {
        return writeConfigs;
    }

    public WriteConfig findById(int id) {
        for (WriteConfig wc : writeConfigs) {
            if (wc.getId() != null && wc.getId() == id) {
                return wc;
            }
        }
        return null;
    }

    /**
     * Checks the write config against SIFFT's rules.
     * Returns null if it is valid, or a short reason if not.
     */
    public String validate(WriteConfig wc) {
        if (wc.getTargetTable() == null || wc.getTargetTable().isBlank()
                || wc.getFormat() == null || wc.getMode() == null || wc.getSchemaMode() == null) {
            return "Missing required field";
        }
        if (!wc.getTargetTable().matches("[a-zA-Z0-9_.]+")) {
            return "targetTable may only contain letters, numbers, underscore and dot";
        }
        if (!FORMATS.contains(wc.getFormat())) {
            return "Invalid format: " + wc.getFormat();
        }
        if (!MODES.contains(wc.getMode())) {
            return "Invalid mode: " + wc.getMode();
        }
        if (!SCHEMA_MODES.contains(wc.getSchemaMode())) {
            return "Invalid schemaMode: " + wc.getSchemaMode();
        }
        if (wc.getMode().equals("merge")) {
            if (!wc.getFormat().equals("delta")) {
                return "Merge mode only works with delta format";
            }
            if (wc.getMergeKeys() == null || wc.getMergeKeys().isEmpty()) {
                return "Merge mode needs at least one merge key";
            }
        }
        return null;
    }

    /** Tells the controller whether a validation message is a vocabulary (422) problem. */
    public boolean isVocabularyError(String message) {
        return message.startsWith("Invalid ") || message.startsWith("Merge mode");
    }

    public WriteConfig save(WriteConfig wc) {
        wc.setId(idCounter);
        idCounter++;
        writeConfigs.add(wc);
        return wc;
    }

    public WriteConfig replace(WriteConfig existing, WriteConfig updated) {
        writeConfigs.remove(existing);
        updated.setId(existing.getId());
        writeConfigs.add(updated);
        return updated;
    }

    public void delete(WriteConfig existing) {
        writeConfigs.remove(existing);
    }
}
