package uk.gov.dvla.siftconfig.models;

import java.util.ArrayList;
import java.util.List;

/**
 * A read configuration: how an inbound file is read (mirrors SIFFT's read options).
 * Extends BaseConfig, inheriting the id attribute and its getter/setter.
 */
public class ReadConfig extends BaseConfig {

    private String pattern;
    private String delimiter;
    private String header;
    private List<String> columns = new ArrayList<>();

    public ReadConfig() {
    }

    public String getPattern() {
        return pattern;
    }

    public void setPattern(String pattern) {
        this.pattern = pattern;
    }

    public String getDelimiter() {
        return delimiter;
    }

    public void setDelimiter(String delimiter) {
        this.delimiter = delimiter;
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public List<String> getColumns() {
        return columns;
    }

    public void setColumns(List<String> columns) {
        this.columns = columns;
    }
}
