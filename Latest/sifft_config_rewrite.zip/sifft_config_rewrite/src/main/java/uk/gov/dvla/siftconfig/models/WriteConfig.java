package uk.gov.dvla.siftconfig.models;

import java.util.ArrayList;
import java.util.List;

/**
 * A write configuration: how a table is written (mirrors SIFFT's TableWriteOptions).
 * Extends BaseConfig, inheriting the id attribute and its getter/setter.
 */
public class WriteConfig extends BaseConfig {

    private String targetTable;
    private String format;
    private String mode;
    private String schemaMode;
    private List<String> mergeKeys = new ArrayList<>();
    private boolean addSourceMetadata;

    public WriteConfig() {
    }

    public String getTargetTable() {
        return targetTable;
    }

    public void setTargetTable(String targetTable) {
        this.targetTable = targetTable;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getSchemaMode() {
        return schemaMode;
    }

    public void setSchemaMode(String schemaMode) {
        this.schemaMode = schemaMode;
    }

    public List<String> getMergeKeys() {
        return mergeKeys;
    }

    public void setMergeKeys(List<String> mergeKeys) {
        this.mergeKeys = mergeKeys;
    }

    public boolean isAddSourceMetadata() {
        return addSourceMetadata;
    }

    public void setAddSourceMetadata(boolean addSourceMetadata) {
        this.addSourceMetadata = addSourceMetadata;
    }
}
