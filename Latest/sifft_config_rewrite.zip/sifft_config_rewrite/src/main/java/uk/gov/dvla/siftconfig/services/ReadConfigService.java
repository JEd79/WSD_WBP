package uk.gov.dvla.siftconfig.services;

import uk.gov.dvla.siftconfig.models.ConfigTestResult;
import uk.gov.dvla.siftconfig.models.ReadConfig;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

/**
 * Holds the read configs in memory and contains the business rules,
 * including the server-side processing that tests a config against a sample line.
 * A Spring service, following the course's "service" package example.
 */
@Service
public class ReadConfigService {

    private static final List<String> HEADER_OPTIONS = Arrays.asList("true", "false", "auto");

    private List<ReadConfig> readConfigs = new ArrayList<>();
    private int idCounter = 1;

    public List<ReadConfig> findAll() {
        return readConfigs;
    }

    public ReadConfig findById(int id) {
        for (ReadConfig rc : readConfigs) {
            if (rc.getId() != null && rc.getId() == id) {
                return rc;
            }
        }
        return null;
    }

    public ReadConfig findByPattern(String pattern) {
        for (ReadConfig rc : readConfigs) {
            if (pattern.equals(rc.getPattern())) {
                return rc;
            }
        }
        return null;
    }

    /** Checks the read config against SIFFT's rules. Returns null if valid, else a reason. */
    public String validate(ReadConfig rc) {
        if (rc.getPattern() == null || rc.getPattern().isBlank()
                || rc.getDelimiter() == null || rc.getHeader() == null
                || rc.getColumns() == null || rc.getColumns().isEmpty()) {
            return "Missing required field";
        }
        if (rc.getDelimiter().length() != 1) {
            return "delimiter must be a single character";
        }
        if (!HEADER_OPTIONS.contains(rc.getHeader())) {
            return "header must be one of: " + HEADER_OPTIONS;
        }
        return null;
    }

    public ReadConfig save(ReadConfig rc) {
        rc.setId(idCounter);
        idCounter++;
        readConfigs.add(rc);
        return rc;
    }

    public ReadConfig replace(ReadConfig existing, ReadConfig updated) {
        readConfigs.remove(existing);
        updated.setId(existing.getId());
        readConfigs.add(updated);
        return updated;
    }

    public void delete(ReadConfig existing) {
        readConfigs.remove(existing);
    }

    /**
     * Server-side processing: split the sample line using the stored delimiter
     * and report whether the field count matches the configured columns.
     */
    public ConfigTestResult test(ReadConfig config, String sampleLine) {
        String delimiter = config.getDelimiter();
        String[] fields = sampleLine.split(Pattern.quote(delimiter), -1);
        int detected = fields.length;
        int expected = config.getColumns().size();
        return new ConfigTestResult(detected, expected, detected == expected, Arrays.asList(fields));
    }
}
