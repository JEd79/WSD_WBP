package uk.gov.dvla.siftconfig.controllers;

import uk.gov.dvla.siftconfig.models.WriteConfig;
import uk.gov.dvla.siftconfig.services.WriteConfigService;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * REST controller for write configs. Thin: it maps HTTP requests to the service
 * and turns the result into the right ResponseEntity.
 */
@RestController
@RequestMapping("/api/v1/write-configs")
public class WriteConfigController {

    private final WriteConfigService service;

    // Spring injects the service (constructor injection).
    public WriteConfigController(WriteConfigService service) {
        this.service = service;
    }

    @GetMapping
    public List<WriteConfig> getAllWriteConfigs() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<WriteConfig> getWriteConfig(@PathVariable int id) {
        WriteConfig found = service.findById(id);
        if (found == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(found);
    }

    @PostMapping
    public ResponseEntity<?> createWriteConfig(@RequestBody WriteConfig writeConfig) {
        String error = service.validate(writeConfig);
        if (error != null) {
            // 422 for vocabulary/rule problems, 400 for structural ones
            if (service.isVocabularyError(error)) {
                return ResponseEntity.unprocessableEntity().body(error);
            }
            return ResponseEntity.badRequest().body(error);
        }
        WriteConfig saved = service.save(writeConfig);
        return ResponseEntity.status(201).body(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateWriteConfig(@PathVariable int id, @RequestBody WriteConfig updated) {
        WriteConfig existing = service.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        String error = service.validate(updated);
        if (error != null) {
            if (service.isVocabularyError(error)) {
                return ResponseEntity.unprocessableEntity().body(error);
            }
            return ResponseEntity.badRequest().body(error);
        }
        return ResponseEntity.ok(service.replace(existing, updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWriteConfig(@PathVariable int id) {
        WriteConfig existing = service.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        service.delete(existing);
        return ResponseEntity.noContent().build();
    }
}
